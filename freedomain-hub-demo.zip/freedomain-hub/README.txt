FREEDOMAIN HUB — FRONTEND DEMO
================================

Cấu trúc:
- index.html : giao diện
- style.css  : giao diện responsive
- app.js     : tương tác và dữ liệu demo

CHẠY THỬ
1. Giải nén ZIP.
2. Mở index.html bằng trình duyệt hoặc upload toàn bộ 3 file lên hosting tĩnh.
3. Đăng ký tài khoản đầu tiên: tài khoản đầu tiên sẽ được gán vai trò Admin DEMO.
4. Đăng xuất, đăng ký tài khoản khác để thử vai trò User.

DEPLOY NETLIFY
1. Upload toàn bộ file lên GitHub repository.
2. Netlify > Add new project > Import an existing project > GitHub.
3. Build command: để trống.
4. Publish directory: . (dấu chấm)
5. Deploy.

GIỚI HẠN QUAN TRỌNG — KHÔNG PHẢI DỊCH VỤ DOMAIN THẬT
- Tài khoản, vai trò, subdomain và danh sách file lưu bằng localStorage trên trình duyệt.
- Không có máy chủ xác thực; mật khẩu demo lưu ở localStorage, không an toàn.
- Đăng ký subdomain chỉ tạo bản ghi demo trên giao diện, không đăng ký DNS công khai.
- Nameserver và DNS record hiển thị là ví dụ, không hoạt động.
- Chọn file chỉ ghi tên/kích thước vào danh sách demo; file không được gửi lên server.
- Dữ liệu không đồng bộ giữa người dùng, thiết bị hoặc trình duyệt.

ĐỂ VẬN HÀNH THẬT CẦN
1. Backend/API (ví dụ Node.js) và database (PostgreSQL/MySQL).
2. Đăng nhập an toàn: hash mật khẩu (Argon2/bcrypt), session/cookie bảo mật, phân quyền kiểm tra ở server.
3. Một hoặc nhiều tên miền gốc do bạn sở hữu, cấu hình wildcard DNS và TLS.
4. DNS provider có API (ví dụ Cloudflare) để tạo/cập nhật DNS records; nameservers chỉ có thể đổi tại registrar/nhà cung cấp phù hợp.
5. Backend upload file, giới hạn dung lượng/loại file, quét file, lưu trữ và phục vụ website qua reverse proxy hoặc static hosting.
6. Quy trình chống lạm dụng, giới hạn tạo subdomain, xác minh email và audit log.

Không đưa API token DNS, mật khẩu hoặc secret vào JavaScript frontend/GitHub công khai.
